# Program Monitoring Kualitas Sinyal SNR - Kelompok B

def kualitas_sinyal(snr):
    """Menentukan kategori kualitas sinyal berdasarkan nilai SNR."""
    if snr < 10:
        return "RENDAH"
    elif snr < 20:
        return "BAIK"
    else:
        return "SANGAT BAIK"

def hitung_kategori(data):
    """Menghitung jumlah data pada setiap kategori."""
    jumlah = {"RENDAH": 0, "BAIK": 0, "SANGAT BAIK": 0}
    for snr in data:
        status = kualitas_sinyal(snr)
        jumlah[status] += 1
    return jumlah

def rata_rata(data):
    """Menghitung rata-rata nilai SNR."""
    return sum(data) / len(data)

# 15 data inti dari soal dan 5 data tambahan
data_snr = [5, 8, 11, 14, 18, 22, 27, 9, 16, 24,
            12, 30, 7, 20, 15, 9, 10, 19, 20, 35]

print("===== MONITORING KUALITAS SINYAL =====")
for nomor, snr in enumerate(data_snr, start=1):
    status = kualitas_sinyal(snr)
    print(f"{nomor:02d}. SNR = {snr} dB -> {status}")

jumlah = hitung_kategori(data_snr)
print("\n===== RINGKASAN =====")
print("Total data      :", len(data_snr))
print("RENDAH          :", jumlah["RENDAH"])
print("BAIK            :", jumlah["BAIK"])
print("SANGAT BAIK     :", jumlah["SANGAT BAIK"])
print(f"Rata-rata SNR   : {rata_rata(data_snr):.2f} dB")
print("Maksimum SNR    :", max(data_snr), "dB")
print("Minimum SNR     :", min(data_snr), "dB")
